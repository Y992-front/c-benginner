#include<iostream>
using namespace std;
struct man
{
    /* data */
    int Id;
    char skill;
    float revenue;

};

int main(){
     struct man yad;
     yad.Id= 001;
     yad.skill= 'k';
     yad.revenue= 120000;
     cout<<"The value of yad Id is "<<yad.Id<<endl;
     cout<<"The value of yad revenue is "<<yad.revenue<<endl;
     cout<<"The value of yad skills is "<<yad.skill<<endl;

    return 0;
}