#include<iostream>
using namespace std ;
int main()
{
 int a = 3;
 int* b = &a ;
 cout <<b<<endl;
 cout<<&a<<endl;
 //both of these commands will give us the address of a //
 // & is addressing operator
 // * is deference operator 
 //value at deference operator //
 cout<<*b<<endl;
 return 0 ;
}
