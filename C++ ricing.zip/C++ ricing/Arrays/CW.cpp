#include<iostream>
using namespace std ;
int main (){
    // int arr[5];
    // arr[0]={10};
    // arr[1]={10};
    // arr[2]={10};
    // arr[3]={10};
    // arr[4]={10};
    // for (int i = 0; i < 5; i++)
    // {
    //     cout<<arr[i]<<endl;
    // }
    int arr[5]={1 , 3 , 4 ,5 ,10};
    for (int i = 0; i < 5; i++)
    {
        cout<<arr[i]<<endl;
    }
    
return 0;
}