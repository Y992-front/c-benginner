#include<iostream>
using namespace std;
int main()
{
    int marks[]={12 , 13 , 16 ,19};
    cout<<marks[0]<<endl;
    cout<<marks[1]<<endl;
    cout<<marks[2]<<endl;
    cout<<marks[3]<<endl;
    // cout<<marks[4]<<endl;
    //for loop
    for (int i = 0; i < 5; i++)
    {
        cout<<"the value of "<<i<<" is " <<marks[i]<<endl;
    }
    //pointer and arrays
    int* a = marks;
    cout<<"the value of *p is "<<*a<<endl;
    cout<<"the value of *p+1 is "<<(*a+1)<<endl;
    cout<<"the value of *p+2 is "<<(*a+2)<<endl;
    cout<<"the value of *p+3 is "<<(*a+3)<<endl;
    return 0 ;
}