#include<iostream>
using namespace std ;
int main(){
    int x[]={1,2,3,4,5,6,7,8,9};
    //the logic given below says that array is an integer datattype has 4 value , if i directly print it , it give 36 value , bcz 4 x 9 = 36 , i have to divide it by int value in bits , then it will give me the value of number of arrays in index.

    //*** int n=sizeof(x)/sizeof(int); //***
    // cout<<n<<endl;

    //U can also write it this this way if u want !
    int n=sizeof(x)/sizeof(x[10]);
    cout<<n<<endl;
    return 0 ;
}