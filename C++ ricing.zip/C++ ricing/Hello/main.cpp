#include <iostream>

using namespace std;

int main()
{
    cout<<"enter your first number "<<endl;
    return 0 ;
}
