#include<iostream>
using namespace std;
struct employee
{
    int Accountname ;
    float Salary ;
    char Yad ;
};
 //Apparently U can also use typedef to create a short way to write this ...
//  typedef struct employee
// {
//     int Accountname ;
//     float Salary ;
//     char Yad ;
// }ep; 
// and now u don't have to write struct employee yadeali , u can just write
// ep yadeali ; // instead of //struct employee yadeali; 


  //Let's talk about unions
    union money
    {
        /* data */
        int rice ;
        char car ;
        float pounds ;
        
    };

int main(){
    struct employee yadeali;
    //U can use different structs datatypes , such as
    struct employee ahmad;
    struct employee wahab;
    //
    yadeali.Accountname=1 ;
    yadeali.Salary=2;
    yadeali.Yad='p';
    // and so as 
    ahmad.Accountname=1 ;
    ahmad.Salary=20;
    ahmad.Yad='L';
    //
     // and so as 
    wahab.Accountname=1 ;
    wahab.Salary=20;
    wahab.Yad='L';
    //

    cout<<"the value of yad e ali is "<<yadeali.Salary<<endl;
    cout<<"the name of yad e ali account is  "<<yadeali.Accountname<<endl;
    cout<<"the value of yad e ali "<<yadeali.Yad<<endl;
    //
     cout<<"the value of ahmad tariq is "<<ahmad.Salary<<endl;
    cout<<"the name of ahmad tariq account is  "<<ahmad.Accountname<<endl;
    cout<<"the value of ahmad tariq "<<ahmad.Yad<<endl;
    //
     cout<<"the value of Atta ul wahab khan is "<<wahab.Salary<<endl;
    cout<<"the name of Atta ul wahab khan account is  "<<wahab.Accountname<<endl;
    cout<<"the value of Atta ul wahab khan "<<wahab.Yad<<endl;
    //
  //Union
  union money m1 ;
//   m1.car ='t';
  m1.rice= 34 ;
//   m1.pounds=340.45;
  //U can't use three or two of them at one time , u can choose to use only one of them 
  cout<<m1.rice<<endl;

//Let's talk about enum
  enum meal{breakfast , lunch , dinner};
  // cout<<breakfast<<endl;
  // cout<<lunch<<endl;
  // cout<<dinner<<endl;

  //U can also allocate in c++
  meal l0=breakfast;
  meal l1=lunch ;
  meal l2=dinner;
  cout<<breakfast<<endl;
  cout<<lunch<<endl;
  cout<<dinner<<endl;
    return 0;
} 