#include<iostream>
using namespace std;
int sum(int a , int b , int d){
    int c = (a+b)*d ;
    return c ;
}
void g();
int main(){
    int num1 , num2 ,num3 ;
    cout<<"Enter first number"<<endl;
    cin>>num1;
    cout<<"Enter second number"<<endl;
    cin>>num2;
     cout<<"Enter 3rd number"<<endl; 
    cin>>num3;
    cout<<"The sum is "<<sum(num1 , num2 ,num3);
    g();
    return 0;

}
void g(){
    cout<<"\n Hello ! Good morning "<<endl;
}