#include<iostream>
using namespace std ;
int main(){
   int n ;
   int sum= 0 ;
   cout<<"Enter the size of array "<<endl;
   cin>>n ;
   int Array[n];
   for (int i = 0; i < n; i++)
   {
    cin>>Array[i];
   }
   for (int i = 0; i < n; i++)
   {
    cout<<" "<<Array[i];
   }
   cout<<"sum of given array is"<<" "<<endl;
   for (int i = 0; i < n; i++)
   {
    if (Array[i]% 2== 0)
    {
        cout<<"Even numbers are "<<Array[i]<<endl;
    }
    
   }
   
    return 0 ;
}