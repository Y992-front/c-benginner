#include<iostream>
using namespace std ;
int main(){
    int A[]={ 1 ,2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10};
    int B[]={1 ,2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10};
   int C[10];
   for (int i = 0; i < 20; i++)
   {
    if (A[i]==B[i])
    {
        A[i]= 0 ;
        B[i]=0 ;
    }
    
   }
   for (int i = 0; i < 10; i++)
   {
     cout<<A[i]<<endl;
   }
    cout<<"yes"<<endl;
   for (int i = 0; i < 10; i++)
   {
     cout<<B[i]<<endl;
   }
    cout<<"No"<<endl;
   
   
    return 0 ;
}