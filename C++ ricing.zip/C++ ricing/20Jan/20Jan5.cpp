#include<iostream>
using namespace std ;
int main(){
   int n ;
   cout<<"Enter number of array :"<<endl;
   cin>>n ;
   int Array[n];
   for (int i = 0; i < n; i++)
   {
    cout<<"Enter data of array :";
    cin>>Array[i];
   }
   for (int i = 0; i < n; i++)
   {
    cout<<Array[i]<<" ";
   }
   
    return 0 ;
}