#include<iostream>
using namespace std ;
int main(){
int n , sum = 0 ;
cout<<"Enter number of arrays :";
cin>>n;
int Array[n];
for (int i = 0; i < n; i++)
{
    cout<<"Enter data of array :";
    cin>>Array[i];
    sum=sum+Array[i];
}
for (int i = 0; i < n; i++)
{
    cout<<Array[i]<<" + ";
}
cout<<"="<<sum;

   
   
    return 0 ;
}