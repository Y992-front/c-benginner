#include<iostream>

using namespace std ;

int main(){

     int A[10]={1 ,2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10} ;
     int B[10]= {11 , 12 , 13 ,14 , 15 , 16 , 17 , 18 , 19 , 20};
     int C [10];
     for (int i= 0 ; i < 10 ; i++)
     {
        C[i]=A[i]+B[i];
     }
     for (int j = 0; j < 10; j++)
     {
        cout<<C[j]<<endl;
     }
     
    return 0 ;
}